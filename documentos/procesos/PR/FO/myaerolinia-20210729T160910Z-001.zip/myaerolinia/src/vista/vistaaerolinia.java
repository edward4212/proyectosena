
package vista;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import org.netbeans.lib.awtextra.*;





public class vistaaerolinia extends JFrame {
    
JLabel lblidvuelo,lblnomciudad_vuelo,lblcordenadas_vuelo,lblcantidad_vuelo,lblpuestos_vuelo,lblfechayhora_vuelo;
JTextField txtidvuelo,txtnomciudad_vuelo,txtcordenadas_vuelo,txtcantidad_vuelo,txtpuesto_vuelo,txtfechayhora_vuelo;
JScrollPane scroll;
DefaultTableModel model;
JTable tblDatos;

JButton btnguardar,btnEliminar,btnAgregar,btnLimpiar,btnPDF;

public vistaaerolinia(){
    this.setTitle(" Aerolinia cariñosita");
    this.setSize(550,600);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setLocationRelativeTo(null);
    this.setLayout(new AbsoluteLayout());
    
    lblidvuelo=new JLabel("N°. vuelo");
    this.getContentPane().add(lblidvuelo,new AbsoluteConstraints(10,10,100,20));
    lblnomciudad_vuelo=new JLabel("Ciudad");
    this.getContentPane().add(lblnomciudad_vuelo,new AbsoluteConstraints(10,40,100,20));
    lblcordenadas_vuelo=new JLabel("coordenadas en Mapa");
    this.getContentPane().add(lblcordenadas_vuelo,new AbsoluteConstraints(10,70,100,20));
    lblcantidad_vuelo=new JLabel("cantidad vuelos");
    this.getContentPane().add(lblcantidad_vuelo,new AbsoluteConstraints(10, 100, 100, 20));
    lblpuestos_vuelo=new JLabel("puesto en avion");
    this.getContentPane().add(lblpuestos_vuelo,new AbsoluteConstraints(10,130,100,20));
    lblfechayhora_vuelo=new JLabel("Fecha y hora ");
    this.getContentPane().add(lblfechayhora_vuelo, new AbsoluteConstraints(10,160,100,20));
    
    txtidvuelo=new JTextField();
    this.getContentPane().add(txtidvuelo,new AbsoluteConstraints(120,10,100,20));
    txtnomciudad_vuelo=new JTextField();
    this.getContentPane().add(txtnomciudad_vuelo,new AbsoluteConstraints(120,40,100,20));
    txtcordenadas_vuelo=new JTextField();
    this.getContentPane().add(txtcordenadas_vuelo,new AbsoluteConstraints(120,70,100,20));
    txtcantidad_vuelo=new JTextField();
    this.getContentPane().add(txtcantidad_vuelo,new AbsoluteConstraints(120,100,100,20));
    txtpuesto_vuelo=new JTextField();
    this.getContentPane().add(txtpuesto_vuelo,new AbsoluteConstraints(120,130,100,20));
    txtfechayhora_vuelo=new JTextField();
    this.getContentPane().add(txtfechayhora_vuelo,new AbsoluteConstraints(120,160,100,20));
    
    btnAgregar=new JButton("Agregar");
    this.getContentPane().add(btnAgregar,new AbsoluteConstraints(300,40,100,20));
    btnEliminar=new JButton("Eliminar");
    this.getContentPane().add(btnEliminar,new AbsoluteConstraints(300,70,100,20));
    btnguardar=new JButton("Guardar");
    this.getContentPane().add(btnguardar,new AbsoluteConstraints(300,100,100,20));
    btnLimpiar=new JButton("Limpiar");
    this.getContentPane().add(btnLimpiar,new AbsoluteConstraints(300,130,100,20));
    btnPDF=new JButton("informe");
    this.getContentPane().add(btnPDF,new AbsoluteConstraints(300,160,100,20));

    
    
   tblDatos = new JTable(); 
    scroll=new JScrollPane();
    model =new DefaultTableModel();
    model.addColumn("N° Vuelo");
    model.addColumn("Ciudad");
    model.addColumn("coordenadas");
    model.addColumn("cantidad vuelos");
    model.addColumn("Puestos en vuelo");
    model.addColumn("fecha y hora");
    tblDatos.setModel(model);
    scroll.setViewportView(tblDatos);
    this.getContentPane().add(scroll,new AbsoluteConstraints(10,200,450,300) );
//    this.setVisible(true);
    

    
    
   
 

}
    public static void main(String[] args) {
        vistaaerolinia c=new vistaaerolinia();
        c.setVisible(true);
    }



    
}
