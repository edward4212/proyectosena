
package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import org.netbeans.lib.awtextra.*;

public class reservas extends JFrame {
    
    JLabel lblrecervaciones,lblidreserva,lblnompasajero_reserva,lblciudad_reserva,lblpuesto_reserva;
    JTextField txtidreserva,txtnompasajero_reserva,txtciudad_reserva,txtpuesto_reserva;
    JScrollPane scroll;
    DefaultTableModel model;
    JTable tbldatos;
    JButton btnguardar,btnEliminar,btnLimpiar;
    JCheckBox  Fila1,Fila2,Fila3,Fila4,Fila5,Fila6,Fila7,Fila8,Fila9,Fila10,Fila11,Fila12,Fila13,Fila14,Fila15;
    

    public reservas(){
    this.setTitle("RESERVACIONES");
    this.setSize(550,600);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setLocationRelativeTo(null);
    this.setLayout(new AbsoluteLayout());
    
   
    lblidreserva = new JLabel("ID reserva");
    this.getContentPane().add(lblidreserva,new AbsoluteConstraints(10,40,100,20));
    
    lblnompasajero_reserva=new JLabel("nombre pasajero");
    this.getContentPane().add(lblnompasajero_reserva,new AbsoluteConstraints(10,70,100,20));
    lblciudad_reserva=new JLabel("Ciudad");
    this.getContentPane().add(lblciudad_reserva,new AbsoluteConstraints(10,100,100,20));
    
    lblpuesto_reserva=new JLabel("seleccionar puesto");
    this.getContentPane().add(lblpuesto_reserva,new AbsoluteConstraints(15,135,400,30));
    
    
    
    
    
    txtidreserva= new JTextField();
    this.getContentPane().add(txtidreserva ,new AbsoluteConstraints(120,40,100,20));   
    txtnompasajero_reserva=new JTextField();
    this.getContentPane().add(txtnompasajero_reserva,new AbsoluteConstraints(120,70,100,20));
    txtciudad_reserva=new JTextField();
    this.getContentPane().add(txtciudad_reserva,new AbsoluteConstraints(120,100,100,20));
   
    
    btnguardar=new JButton("Agregar");
    this.getContentPane().add(btnguardar,new AbsoluteConstraints(300,40,100,20));
    btnEliminar=new JButton("Eliminar");
    this.getContentPane().add(btnEliminar,new AbsoluteConstraints(300,70,100,20));
    
    
            
            
            this.setVisible(true);
    
            
            
        setLayout(null);
        
            Fila1=new JCheckBox("fila 1",true);
            Fila1.setBounds(10,170,100,20);
            Fila1.getContainerListeners();
            add(Fila1);
            
            
            Fila2=new JCheckBox("fila 2");
            Fila2.setBounds(10,200,100,20);
            Fila2.getContainerListeners();
            add(Fila2);
            
            
            Fila3=new JCheckBox("fila 3");
            Fila3.setBounds(10,230,100,20);
            Fila3.getContainerListeners();
            add(Fila3);
            
            Fila4=new JCheckBox("fila 4");
            Fila4.setBounds(10,260,100,20);
            Fila4.getContainerListeners();
            add(Fila4);
            
            Fila5=new JCheckBox("fila 5",true);
            Fila5.setBounds(10,290,100,20);
            Fila5.getContainerListeners();
            add(Fila5);
            
            
            Fila6=new JCheckBox("fila 6");
            Fila6.setBounds(10,320,100,20);
            Fila6.getContainerListeners();
            add(Fila6);
            
            
            Fila7=new JCheckBox("fila 7");
            Fila7.setBounds(10,350,80,20);
            Fila7.getContainerListeners();
            add(Fila7);
            
            Fila8=new JCheckBox("fila 8");
            Fila8.setBounds(10,380,100,20);
            Fila8.getContainerListeners();
            add(Fila8);
            
            
            Fila9=new JCheckBox("fila 9",true);
            Fila9.setBounds(170,170,100,20);
            Fila9.getContainerListeners();
            add(Fila9);
            
            
            Fila10=new JCheckBox("fila 10");
            Fila10.setBounds(170,200,100,20);
            Fila10.getContainerListeners();
            add(Fila10);
            
            
            Fila11=new JCheckBox("fila 11");
            Fila11.setBounds(170,230,100,20);
            Fila11.getContainerListeners();
            add(Fila11);
            
            Fila12=new JCheckBox("fila 12");
            Fila12.setBounds(170,260,100,20);
            Fila12.getContainerListeners();
            add(Fila12);
            
            Fila13=new JCheckBox("fila 13",true);
            Fila13.setBounds(170,290,100,20);
            Fila13.getContainerListeners();
            add(Fila13);
            
            
            Fila14=new JCheckBox("fila 14");
            Fila14.setBounds(170,320,100,20);
            Fila14.getContainerListeners();
            add(Fila14);
            
              Fila15=new JCheckBox("fila 15");
            Fila15.setBounds(170,350,100,20);
            Fila15.getContainerListeners();
            add(Fila15);
    
            
   
    }
    
    
    
    
    public static void main(String[] args) {
        reservas c=new reservas();
        c.setVisible(true);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}
