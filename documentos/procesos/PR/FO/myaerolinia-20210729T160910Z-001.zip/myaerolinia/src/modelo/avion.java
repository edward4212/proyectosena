
package modelo;

import javax.swing.JOptionPane;


public class avion {
    private int idavion;
      private String modelo_avion;

    public avion() {
        
        JOptionPane.showMessageDialog(null, "se ha creado el avion");
        
    }

    public avion(String modelo_avion) {
        this.modelo_avion = modelo_avion;
    }

    public avion(int idavion, String modelo_avion) {
        this.idavion = idavion;
        this.modelo_avion = modelo_avion;
    }
      
      
      
      
      
    public int getIdavion(){
        return idavion;
        
    
    }
    public void setIdavion(int idavion){
    this.idavion=idavion;
    
    }
    
    public String getModelo_avion(){
    
    return modelo_avion;
    
    }
    public void setModelo_avion(String modelo_avion){
    this.modelo_avion=modelo_avion;
    
    
    }
    
}
