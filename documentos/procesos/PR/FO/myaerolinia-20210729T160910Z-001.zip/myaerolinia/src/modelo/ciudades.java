
package modelo;
import javax.swing.JOptionPane;

public class ciudades {
    private int idciudades;
      private String nom_ciudades;
        private String coordenadas_ciudades;

    public ciudades() {
        JOptionPane.showMessageDialog(null, "se ha creado ciudades");
    }

    public ciudades(String nom_ciudades, String coordenadas_ciudades) {
        this.nom_ciudades = nom_ciudades;
        this.coordenadas_ciudades = coordenadas_ciudades;
    }

    public ciudades(int idciudades, String nom_ciudades, String coordenadas_ciudades) {
        this.idciudades = idciudades;
        this.nom_ciudades = nom_ciudades;
        this.coordenadas_ciudades = coordenadas_ciudades;
    }
        
        

    public int getIdciudades() {
        return idciudades;
    }

    public void setIdciudades(int idciudades) {
        this.idciudades = idciudades;
    }

    public String getNom_ciudades() {
        return nom_ciudades;
    }

    public void setNom_ciudades(String nom_ciudades) {
        this.nom_ciudades = nom_ciudades;
    }

    public String getCoordenadas_ciudades() {
        return coordenadas_ciudades;
    }

    public void setCoordenadas_ciudades(String coordenadas_ciudades) {
        this.coordenadas_ciudades = coordenadas_ciudades;
    }
        
        
        
    
}
