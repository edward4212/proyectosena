
package modelo;

import javax.swing.JOptionPane;


public class vuelo {
    private int idvuelos;
    private String nomciudad_vuelo;
    private String cordenadas_vuelo;
    private String cantidad_vuelo;
    private String puestos_vuelo;
    private String fechayhora_vuelo;
    
    public static void main(String[] args) {
        vuelo c=new vuelo();
        c.setNomciudad_vuelo("NEW YOR");
        c.setFechayhora_vuelo("2:30 am del 9/12/2019");
        JOptionPane.showMessageDialog(null,"los datos del vuelo son:"+c.getNomciudad_vuelo()+""+c.getFechayhora_vuelo());
    }

    public vuelo() {
        JOptionPane.showMessageDialog(null, "se ha creado el vuelo");
    }

    public vuelo(int idvuelos, String nomciudad_vuelo, String cordenadas_vuelo, String cantidad_vuelo, String puestos_vuelo, String fechayhora_vuelo) {
        this.idvuelos = idvuelos;
        this.nomciudad_vuelo = nomciudad_vuelo;
        this.cordenadas_vuelo = cordenadas_vuelo;
        this.cantidad_vuelo = cantidad_vuelo;
        this.puestos_vuelo = puestos_vuelo;
        this.fechayhora_vuelo = fechayhora_vuelo;
    }

    public vuelo(String nomciudad_vuelo, String cordenadas_vuelo, String cantidad_vuelo, String puestos_vuelo, String fechayhora_vuelo) {
        this.nomciudad_vuelo = nomciudad_vuelo;
        this.cordenadas_vuelo = cordenadas_vuelo;
        this.cantidad_vuelo = cantidad_vuelo;
        this.puestos_vuelo = puestos_vuelo;
        this.fechayhora_vuelo = fechayhora_vuelo;
    }
    
    
    

    public int getIdvuelos() {
        return idvuelos;
    }

    public void setIdvuelos(int idvuelos) {
        this.idvuelos = idvuelos;
    }

    public String getNomciudad_vuelo() {
        return nomciudad_vuelo;
    }

    public void setNomciudad_vuelo(String nomciudad_vuelo) {
        this.nomciudad_vuelo = nomciudad_vuelo;
    }

    public String getCordenadas_vuelo() {
        return cordenadas_vuelo;
    }

    public void setCordenadas_vuelo(String cordenadas_vuelo) {
        this.cordenadas_vuelo = cordenadas_vuelo;
    }

    public String getCantidad_vuelo() {
        return cantidad_vuelo;
    }

    public void setCantidad_vuelo(String cantidad_vuelo) {
        this.cantidad_vuelo = cantidad_vuelo;
    }

    public String getPuestos_vuelo() {
        return puestos_vuelo;
    }

    public void setPuestos_vuelo(String puestos_vuelo) {
        this.puestos_vuelo = puestos_vuelo;
    }

    public String getFechayhora_vuelo() {
        return fechayhora_vuelo;
    }

    public void setFechayhora_vuelo(String fechayhora_vuelo) {
        this.fechayhora_vuelo = fechayhora_vuelo;
    }
    
    
    
    
    
    
}
