
package modelo;

import javax.swing.JOptionPane;


public class pasajeros {
    private int idpasajeros;
      private String nom_pasajero;
        private String ape_pasajero;
          private String destino_pasajero;
            private String tel_pasajero;
              private String vuelo_pasajero;

    public pasajeros() {
        JOptionPane.showMessageDialog(null,"se ha creado el pasajero");
    }

    public pasajeros(int idpasajeros, String nom_pasajero, String ape_pasajero, String destino_pasajero, String tel_pasajero, String vuelo_pasajero) {
        this.idpasajeros = idpasajeros;
        this.nom_pasajero = nom_pasajero;
        this.ape_pasajero = ape_pasajero;
        this.destino_pasajero = destino_pasajero;
        this.tel_pasajero = tel_pasajero;
        this.vuelo_pasajero = vuelo_pasajero;
    }

    public pasajeros(String nom_pasajero, String ape_pasajero, String destino_pasajero, String tel_pasajero, String vuelo_pasajero) {
        this.nom_pasajero = nom_pasajero;
        this.ape_pasajero = ape_pasajero;
        this.destino_pasajero = destino_pasajero;
        this.tel_pasajero = tel_pasajero;
        this.vuelo_pasajero = vuelo_pasajero;
    }
    
              

    public int getIdpasajeros() {
        return idpasajeros;
    }

    public void setIdpasajeros(int idpasajeros) {
        this.idpasajeros = idpasajeros;
    }

    public String getNom_pasajero() {
        return nom_pasajero;
    }

    public void setNom_pasajero(String nom_pasajero) {
        this.nom_pasajero = nom_pasajero;
    }

    public String getApe_pasajero() {
        return ape_pasajero;
    }

    public void setApe_pasajero(String ape_pasajero) {
        this.ape_pasajero = ape_pasajero;
    }

    public String getDestino_pasajero() {
        return destino_pasajero;
    }

    public void setDestino_pasajero(String destino_pasajero) {
        this.destino_pasajero = destino_pasajero;
    }

    public String getTel_pasajero() {
        return tel_pasajero;
    }

    public void setTel_pasajero(String tel_pasajero) {
        this.tel_pasajero = tel_pasajero;
    }

    public String getVuelo_pasajero() {
        return vuelo_pasajero;
    }

    public void setVuelo_pasajero(String vuelo_pasajero) {
        this.vuelo_pasajero = vuelo_pasajero;
    }
              
    
    
    
    
}
