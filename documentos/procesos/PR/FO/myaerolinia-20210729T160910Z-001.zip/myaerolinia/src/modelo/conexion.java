
package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class conexion {
    Connection cn;
    String bd="aerolinia";
    String url="jdbc:mysql://localhost:3306/"+bd;
    String user="root";
    String password="";
    
    
    public Connection conectar(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            cn=(Connection)DriverManager.getConnection(url,user,password);
            JOptionPane.showMessageDialog(null,"conectado a la base de datos:"+""+bd);
            
        
        
        }catch (ClassNotFoundException | SQLException ex){
        Logger.getLogger(conexion.class.getName()).log(Level.SEVERE,null,ex);
        JOptionPane.showMessageDialog(null,"no se coneto a la base de datos"+ex);
        
        }
     
    return cn;
    
    
    
    }
    public void Desconectar(){
        try{
            cn.close();
            JOptionPane.showMessageDialog(null, "cerrando la conexion a la base de datos");
            
        
        
        }catch(SQLException ex){
            
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE,null,ex);
            JOptionPane.showMessageDialog(null, "No se cerró la conexion a la base de datos"+ex);
        }
    }
    
}

