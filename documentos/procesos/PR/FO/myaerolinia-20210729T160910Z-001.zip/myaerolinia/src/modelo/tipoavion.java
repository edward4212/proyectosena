
package modelo;
import javax.swing.JOptionPane;

public class tipoavion {
    private int idtipoavion;
    private String nom_tipoavion;
    private String cantidad_sillas;
    public static void main(String[] args) {
        
    tipoavion c=new tipoavion();
    c.setNom_tipoavion("lorenxo");
    c.setCantidad_sillas("15 filas/5 sillas por fila");
    
        JOptionPane.showMessageDialog(null,"el tipo de avion es"+c.getNom_tipoavion()+""+c.getCantidad_sillas());
    }

    public tipoavion() {
        JOptionPane.showMessageDialog(null,"se ha creado el tipo de avion");
    }

    public tipoavion(int idtipoavion, String nom_tipoavion, String cantidad_sillas) {
        this.idtipoavion = idtipoavion;
        this.nom_tipoavion = nom_tipoavion;
        this.cantidad_sillas = cantidad_sillas;
    }

    public tipoavion(String nom_tipoavion, String cantidad_sillas) {
        this.nom_tipoavion = nom_tipoavion;
        this.cantidad_sillas = cantidad_sillas;
    }
    
    

    public int getIdtipoavion() {
        return idtipoavion;
    }

    public void setIdtipoavion(int idtipoavion) {
        this.idtipoavion = idtipoavion;
    }

    public String getNom_tipoavion() {
        return nom_tipoavion;
    }

    public void setNom_tipoavion(String nom_tipoavion) {
        this.nom_tipoavion = nom_tipoavion;
    }

    public String getCantidad_sillas() {
        return cantidad_sillas;
    }

    public void setCantidad_sillas(String cantidad_sillas) {
        this.cantidad_sillas = cantidad_sillas;
    }
    
    
    
    
    
}
