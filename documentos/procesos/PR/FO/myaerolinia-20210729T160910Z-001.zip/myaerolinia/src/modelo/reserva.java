
package modelo;

import javax.swing.JOptionPane;

public class reserva {
    
    private int idreserva;
    private String nompasajero_reserva;
    private String ciudad_reserva;
    private String puesto_reserva;

    public reserva() {
        JOptionPane.showMessageDialog(null, "se ha creado la reserva");
    }

    public reserva(int idreserva, String nompasajero_reserva, String ciudad_reserva, String puesto_reserva) {
        this.idreserva = idreserva;
        this.nompasajero_reserva = nompasajero_reserva;
        this.ciudad_reserva = ciudad_reserva;
        this.puesto_reserva = puesto_reserva;
    }

    public reserva(String nompasajero_reserva, String ciudad_reserva, String puesto_reserva) {
        this.nompasajero_reserva = nompasajero_reserva;
        this.ciudad_reserva = ciudad_reserva;
        this.puesto_reserva = puesto_reserva;
    }
    

    public int getIdreserva() {
        return idreserva;
    }

    public void setIdreserva(int idreserva) {
        this.idreserva = idreserva;
    }

    public String getNompasajero_reserva() {
        return nompasajero_reserva;
    }

    public void setNompasajero_reserva(String nompasajero_reserva) {
        this.nompasajero_reserva = nompasajero_reserva;
    }

    public String getCiudad_reserva() {
        return ciudad_reserva;
    }

    public void setCiudad_reserva(String ciudad_reserva) {
        this.ciudad_reserva = ciudad_reserva;
    }

    public String getPuesto_reserva() {
        return puesto_reserva;
    }

    public void setPuesto_reserva(String puesto_reserva) {
        this.puesto_reserva = puesto_reserva;
    }

    
    
    
  
    
    
    
    
    
          
    
    
}
